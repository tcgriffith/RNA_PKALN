extern void		StringToken(int *start, int *finish, int s_length, char *s, char *delimit, char *token);
int			strchr_b(char *delimit, char x);
