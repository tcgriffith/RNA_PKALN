extern void	 PrintErrorAndExitSafely(char *string);
